def main():
    print("valid node (mock)")

if __name__ == "__main__":
    main()
