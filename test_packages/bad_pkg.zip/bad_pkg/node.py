def main()
    print("broken syntax")
